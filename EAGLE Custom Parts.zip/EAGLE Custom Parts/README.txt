Folder of custom EAGLE parts
